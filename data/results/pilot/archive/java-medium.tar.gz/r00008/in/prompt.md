You are working in the repository at /workspace. This environment has standard command-line utilities, git and
ripgrep, but no compilers, interpreters, test runners, package managers or network access, and nothing can be
installed. Work only inside /workspace. When you are done, stop; do not ask questions, nobody will answer.

Rename the file `gson/src/main/java/com/google/gson/internal/ObjectConstructor.java` to `ObjectFactory.java` in the
same package, and the interface it declares to `ObjectFactory`, throughout the core `gson/` module, main code and tests
(the `extras/`, `metrics/` and `proto/` modules are out of scope). Do not keep the old name as an alias. Comments and
Javadoc that refer to the interface should follow the new name; other types whose names merely contain the old name
keep their names.
