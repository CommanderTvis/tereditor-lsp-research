You are working in the repository at /workspace. This environment has standard command-line utilities, git and
ripgrep, but no compilers, interpreters, test runners, package managers or network access, and nothing can be
installed. Work only inside /workspace. When you are done, stop; do not ask questions, nobody will answer.

`LlmReferenceProvider` (`embabel-agent-api/src/main/kotlin/com/embabel/agent/api/reference/LlmReferenceProvider.kt`) declares `fun reference(): LlmReference` (line 35), and several classes provide it: literal text, web pages, directory references and chat assets.

Consider a call `provider.reference()` where `provider` is statically an `LlmReferenceProvider` and the object it holds is a `LocalDirectoryReference` (`com.embabel.agent.api.reference.LocalDirectoryReference`). Which function runs?

Write the answer to `ANSWER.txt` in the repository root as one line, `path:line`: the path of the source file that defines that function, relative to the repository root, and the line of its definition on which the function's name appears.
