You are working in the repository at /workspace. This environment has standard command-line utilities, git and
ripgrep, but no compilers, interpreters, test runners, package managers or network access, and nothing can be
installed. Work only inside /workspace. When you are done, stop; do not ask questions, nobody will answer.

The planner interface `com.embabel.plan.Planner` (`embabel-agent-api/src/main/kotlin/com/embabel/plan/Planner.kt`) declares

```kotlin
fun planToGoal(
    actions: Collection<Action>,
    goal: Goal,
): P?
```

Change its signature so that the goal comes first: `planToGoal(goal: Goal, actions: Collection<Action>)`. Update everything that implements, overrides or calls it, in main code and tests: the implementations, the default method of the interface that calls it, the validator, and the test call sites. The similarly named `planToGoalFrom` of the GOAP planners is a different method and keeps its signature.

The project must still build and the existing tests must pass.
