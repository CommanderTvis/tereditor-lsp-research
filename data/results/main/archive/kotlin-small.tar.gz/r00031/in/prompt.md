You are working in the repository at /workspace. This environment has standard command-line utilities, git and
ripgrep, but no compilers, interpreters, test runners, package managers or network access, and nothing can be
installed. Work only inside /workspace. When you are done, stop; do not ask questions, nobody will answer.

# `ComposeReadOnlyComposable` false negative on read in default argument expression

```kotlin
object MaterialTheme {
    val colorScheme: ColorScheme
        @Composable @ReadOnlyComposable get() = TODO()
}

@Composable
fun fadeHighlightColor(
    backgroundColor: Color = MaterialTheme.colorScheme.surface,
    alpha: Float = 0.3f,
): Color = backgroundColor.copy(alpha = alpha)
```
Not flagged with 1.5.5.
