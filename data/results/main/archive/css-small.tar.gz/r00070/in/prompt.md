You are working in the repository at /workspace. This environment has standard command-line utilities, git and
ripgrep, but no compilers, interpreters, test runners, package managers or network access, and nothing can be
installed. Work only inside /workspace. When you are done, stop; do not ask questions, nobody will answer.

The mixin `deprecate` in `core/scss/mixins/bootstrap/_deprecate.scss` takes
`($name, $deprecate-version, $remove-version, $ignore-warning: false)`. We want the version first:

    @mixin deprecate($deprecate-version, $name, $remove-version, $ignore-warning: false)

Change the mixin and update every place that includes it, so that the stylesheets compile to exactly the same CSS and the
messages stay the same. Do not add a second mixin or a wrapper with the old order.
