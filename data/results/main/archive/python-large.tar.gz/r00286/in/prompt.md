You are working in the repository at /workspace. This environment has standard command-line utilities, git and
ripgrep, but no compilers, interpreters, test runners, package managers or network access, and nothing can be
installed. Work only inside /workspace. When you are done, stop; do not ask questions, nobody will answer.

Overloaded function as a subtype of function with union types args/return

This code should probably be valid:

``` python
from typing import Callable, Union, overload

def f(fn: Callable[[Union[int, str]], Union[int, str]]) -> None: pass

@overload
def g(x: int) -> int: ...
@overload
def g(x: str) -> str: ...
def g(x): ...

f(g)   # Currently error
```

I.e., an overloaded function should be a subtype of a suitable function with union type arguments and return value.
