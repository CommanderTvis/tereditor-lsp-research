You are working in the repository at /workspace. This environment has standard command-line utilities, git and
ripgrep, but no compilers, interpreters, test runners, package managers or network access, and nothing can be
installed. Work only inside /workspace. When you are done, stop; do not ask questions, nobody will answer.

The request wrapper `Request` lives in the `Yajra\DataTables\Utilities` namespace, but it is a core part of the package, not a utility. Move it one namespace up, into the package's root namespace: it should become `Yajra\DataTables\Request`, in `src/Request.php`, following the package's PSR-4 layout. Update every reference in the library and the tests. Do not leave the old class behind and do not add an alias for the old name. The other classes in `Utilities` (`Config`, `Helper`) stay where they are, and `Illuminate\Http\Request` is unrelated. Updating documentation files is optional.
