You are working in the repository at /workspace. This environment has standard command-line utilities, git and
ripgrep, but no compilers, interpreters, test runners, package managers or network access, and nothing can be
installed. Work only inside /workspace. When you are done, stop; do not ask questions, nobody will answer.

For consistency with how we build schema objects, `QueryRunner.createCheckConstraint` should take the check
constraint first and the table second: `createCheckConstraint(checkConstraint, tableOrName)` instead of
`createCheckConstraint(tableOrName, checkConstraint)`.

Change the declaration in the `QueryRunner` interface (`packages/typeorm/src/query-runner/QueryRunner.ts`), every
query runner that implements it, and every call of it in the code base, including the tests and the test
migrations, so that the package compiles and the tests pass. Do not keep an overload or fallback for the old
argument order. Updating the documentation is optional.
