You are working in the repository at /workspace. This environment has standard command-line utilities, git and
ripgrep, but no compilers, interpreters, test runners, package managers or network access, and nothing can be
installed. Work only inside /workspace. When you are done, stop; do not ask questions, nobody will answer.

Move the class template `iterator_buffer`, together with all of its partial specializations, out of the internal
namespace `fmt::detail` into the public namespace `fmt`, so that users can name it as `fmt::iterator_buffer`. It stays
in `include/fmt/base.h`. Update every reference to it in the headers, sources and tests. Do not leave an alias, a
using-declaration or a forwarding declaration of it in `fmt::detail`.
