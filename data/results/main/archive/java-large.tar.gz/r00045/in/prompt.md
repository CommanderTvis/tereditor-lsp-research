You are working in the repository at /workspace. This environment has standard command-line utilities, git and
ripgrep, but no compilers, interpreters, test runners, package managers or network access, and nothing can be
installed. Work only inside /workspace. When you are done, stop; do not ask questions, nobody will answer.

`AnnotationIntrospector.findPolymorphicBaseType(MapperConfig<?> config, AnnotatedClass ac, JsonTypeInfo.Value typeInfo,
JavaType assumedBaseType)` never uses its `typeInfo` argument, and neither does any implementation. Remove that
parameter: the method becomes `findPolymorphicBaseType(MapperConfig<?> config, AnnotatedClass ac, JavaType
assumedBaseType)` in `AnnotationIntrospector` and in every class that overrides it, main code and tests, and every
caller passes one argument less. Do not keep the four-argument variant, and drop the parameter from the Javadoc.
Behaviour must not change.
