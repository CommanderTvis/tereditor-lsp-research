You are working in the repository at /workspace. This environment has standard command-line utilities, git and
ripgrep, but no compilers, interpreters, test runners, package managers or network access, and nothing can be
installed. Work only inside /workspace. When you are done, stop; do not ask questions, nobody will answer.

Rename the method `getData()` of the `Dedoc\Scramble\Infer\Contracts\ClassDefinition` contract to `getDefinitionData()`: in the contract, in every class that implements it, and at every place that calls it or refers to it by name, in the library and the tests. Do not keep the old name as an alias. Updating documentation files and comments is optional.
