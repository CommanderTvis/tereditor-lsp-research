You are working in the repository at /workspace. This environment has standard command-line utilities, git and
ripgrep, but no compilers, interpreters, test runners, package managers or network access, and nothing can be
installed. Work only inside /workspace. When you are done, stop; do not ask questions, nobody will answer.

# Difference between MD4C and cmark output for CDATA tags

Input:
```
<![CDATA[ text ]]>
<![cdata[ text ]]>
<PrE>text</pRe>
<foo>text</foo>
```

cmark output:
```
<![CDATA[ text ]]>
<p>&lt;![cdata[ text ]]&gt;</p>
<pre>text</pre>
<p><foo>text</foo></p>
```

md4c output:
```
<![CDATA[ text ]]>
<!cdata[ text ]>
<pre>text</pre>
<p><foo>text</foo></p>
```
