You are working in the repository at /workspace. This environment has standard command-line utilities, git and
ripgrep, but no compilers, interpreters, test runners, package managers or network access, and nothing can be
installed. Work only inside /workspace. When you are done, stop; do not ask questions, nobody will answer.

Move the function `bats_setup_tracing` out of `lib/bats-core/tracing.bash` into a new library file,
`lib/bats-core/setup_tracing.bash`, in the same directory as the other libraries. After the change:

- `bats_setup_tracing` is defined only in `lib/bats-core/setup_tracing.bash`;
- `lib/bats-core/tracing.bash` neither defines it nor sources the new file: every script that calls
  `bats_setup_tracing` must load `setup_tracing.bash` itself;
- bats works exactly as before and its test suite (including its shellcheck test) still passes.

Do not change what the function does.
