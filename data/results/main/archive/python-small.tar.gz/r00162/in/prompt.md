You are working in the repository at /workspace. This environment has standard command-line utilities, git and
ripgrep, but no compilers, interpreters, test runners, package managers or network access, and nothing can be
installed. Work only inside /workspace. When you are done, stop; do not ask questions, nobody will answer.

Rename the module `pydantic_extra_types/phone_numbers.py` to `pydantic_extra_types/phone_number.py` (singular, like the
type it defines). Update every import and module reference in the code, the tests and the docstring examples so the
project continues to work, and remove the old path. The test files keep their names.
