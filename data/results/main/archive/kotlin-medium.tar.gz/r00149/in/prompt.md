You are working in the repository at /workspace. This environment has standard command-line utilities, git and
ripgrep, but no compilers, interpreters, test runners, package managers or network access, and nothing can be
installed. Work only inside /workspace. When you are done, stop; do not ask questions, nobody will answer.

Which types in this repository implement `com.squareup.kotlinpoet.Taggable`, directly or through other types
(subclasses of an implementing class count too)? Count named classes, interfaces and objects declared in the
repository's Kotlin and Java sources, main and test code of every module; do not count `Taggable` itself, anonymous
objects, or types from libraries. `Taggable.Builder` is a different type: neither it nor its implementations count
unless they also implement `Taggable`.

Write the result to `ANSWER.txt` in the repository root, one fully qualified name per line, with nested types
written with dots (for example `com.squareup.kotlinpoet.Foo.Bar`).
