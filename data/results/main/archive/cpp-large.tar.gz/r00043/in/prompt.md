You are working in the repository at /workspace. This environment has standard command-line utilities, git and
ripgrep, but no compilers, interpreters, test runners, package managers or network access, and nothing can be
installed. Work only inside /workspace. When you are done, stop; do not ask questions, nobody will answer.

Rename Redis's own `sdsnewlen` (declared in `src/sds.h`, defined in `src/sds.c`) to `sdsnewbuf`, at every call site
and every mention in comments of the server, the tools in `src/` and the modules in `modules/` and `tests/modules/`.
Do not keep the old name as an alias or macro. The vendored libraries under `deps/` have their own SDS implementation,
which keeps its names; do not modify anything under `deps/`.
