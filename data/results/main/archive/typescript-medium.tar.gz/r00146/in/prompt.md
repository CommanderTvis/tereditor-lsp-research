You are working in the repository at /workspace. This environment has standard command-line utilities, git and
ripgrep, but no compilers, interpreters, test runners, package managers or network access, and nothing can be
installed. Work only inside /workspace. When you are done, stop; do not ask questions, nobody will answer.

The module `src/utils/encode.ts` only contains the base64 and base64url helpers, so rename it to
`src/utils/base64.ts`, and rename its test file `src/utils/encode.test.ts` to `src/utils/base64.test.ts`. Update
every import of the module across the code base and tests, and the entry for it in `jsr.json` (both the export key,
which becomes `./utils/base64`, and the path). Do not leave a file at the old path or a module that re-exports the
new one under the old name. The type check and the tests must pass.
