You are working in the repository at /workspace. This environment has standard command-line utilities, git and
ripgrep, but no compilers, interpreters, test runners, package managers or network access, and nothing can be
installed. Work only inside /workspace. When you are done, stop; do not ask questions, nobody will answer.

In Spectre.Console, `AnsiConsoleFacade` (`src/Spectre.Console/Internal/Backends/AnsiConsoleFacade.cs`) writes through an `IAnsiConsoleBackend` chosen by `GetBackend()`. For a console whose profile reports `Capabilities.Ansi == true`, which concrete class's `Write(IRenderable)` runs when `AnsiConsoleFacade.Write(IRenderable)` is called?

Write the fully qualified name of that class (namespace and class name) as the only line of `ANSWER.txt` at the repository root.
