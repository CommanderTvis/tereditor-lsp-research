You are working in the repository at /workspace. This environment has standard command-line utilities, git and
ripgrep, but no compilers, interpreters, test runners, package managers or network access, and nothing can be
installed. Work only inside /workspace. When you are done, stop; do not ask questions, nobody will answer.

In `src/Spectre.Console/Prompts/List/IListPromptStrategy.cs`, the `Render` method of the internal interface `IListPromptStrategy<T>` takes `IAnsiConsole console` as its first parameter. Make it the last parameter instead: the other parameters keep their order and types, and `console` follows `searchText`. Update the interface, both implementations and every call site so that the solution still builds and its tests pass. Behavior must not change.
