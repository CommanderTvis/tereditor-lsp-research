You are working in the repository at /workspace. This environment has standard command-line utilities, git and
ripgrep, but no compilers, interpreters, test runners, package managers or network access, and nothing can be
installed. Work only inside /workspace. When you are done, stop; do not ask questions, nobody will answer.

Rename the class `org.apache.lucene.util.QueryBuilder` (lucene/core) to `TextQueryBuilder`, in the same package, together with its source file, and update everything that uses it in every module of the repository, main code and tests. Comments and Javadoc that refer to the class should follow the new name. Do not keep the old name as an alias. The other classes called `QueryBuilder` (in the queryparser module) are different types and keep their names.
