You are working in the repository at /workspace. This environment has standard command-line utilities, git and
ripgrep, but no compilers, interpreters, test runners, package managers or network access, and nothing can be
installed. Work only inside /workspace. When you are done, stop; do not ask questions, nobody will answer.

Find every use of `salt.exceptions.SaltException` in Python source code in this repository. Include imports, subclasses, raises, catches, and constructor calls that resolve to this class. Exclude its definition, comments, docstrings, strings, and unrelated bindings. Write each location to `ANSWER.txt` as `relative/path.py:LINE`, one per line.
